import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import mpi.*;

public class svetibog {

	public static void main(String[] args) {
		MPI.Init(args);
		int rank=MPI.COMM_WORLD.Rank();

		if(rank==0) {
			int[] X = new int[1000];
			int[] Y = new int[1000];
			int[] V = new int[1000];
			int[] C = new int[1000];
			int[] flag= new int[1];
			int cycles=2;
			flag[0] =1;
			randomizer rajkan=new randomizer();
    		for(int i=0;i<5;i++) {
    			X[i]=rajkan.x();
    			Y[i]=rajkan.y();
    			V[i]=rajkan.vel();
    			C[i]=rajkan.c();
    		}

    		
			long k1=System.currentTimeMillis();

	    		MPI.COMM_WORLD.Send(flag, 0, 1, MPI.INT, 1, 1);
	    		MPI.COMM_WORLD.Send(X, 0, X.length, MPI.INT, 1, 1);

	    	long k2=System.currentTimeMillis()-k1;
	    	System.out.println(k2);
		}

		if(rank==1) {
			int s=0;
			int q=333;
			int[] X = new int[1000];
			int flag;
			int p=0;
			MPI.COMM_WORLD.Recv(X, 0, X.length, MPI.INT, 1, 1);
			for(int i=s;i<333;i++) {
				 p=+X[i];
			}
			System.out.print(p);
			
			
		}
		if(rank==2) {
			int s=333;
			int q=666;
			
		}
		if(rank==3) {
			int s=666;
			int q=999;
			
		}
		MPI.Finalize();
	}


}


class randomizer1 {
	int c() {
    	Random rand= new Random();
    	int rand1=rand.nextInt(2);
    	if(rand1==0)
    		rand1=-1;
    	return rand1;
    	}

    
    int vel() {
    	Random rand= new Random();
    	int rand1= rand.nextInt(10);
    	if(rand1>5)
    		rand1=(rand1-5)*(-1);
    	return rand1;
    } 
    
    int x() {
    	Random rand= new Random();
    	int rand1= rand.nextInt(800);
    	return rand1;
    }
    
    int y() {
    	Random rand= new Random();
    	int rand1= rand.nextInt(600);
    	return rand1;
    }
}

class pentaint1{
	int xdif;
	int ydif;
	double angle;
	int hypotenuse;
	int charge;
}



class Program1 {
	int cycles=500;
	int nparticles=100;
	int threads=1;
    private List<Particle> particles;
    private List<Particle> depositparticles;

    
    int charger() {
    	Random rand= new Random();
    	return rand.nextInt(2);
    }
    
    int vel() {
    	Random rand= new Random();
    	int rand1= rand.nextInt(10);
    	if(rand1>5)
    		rand1=(rand1-5)*(-1);
    	return rand1;
    } 
    
    int directioner() {
    	Random rand= new Random();
    	return rand.nextInt(360);
    }
    int charg2e(int k){
    	if(k==0)
    		return -1;
    	else 
    		return 1;
    }

    void run1() {


        
        
       
        	//while (cycles>0) {
        		//for (Particle b: particles) {
                //b.update();
                //depositparticles=particles;
            //}
            //cycles--;
        //} 
        
    
        
    }

 

    class Particle {
        int posX, posY, size;
        int xacceleration;
        int yacceleration;
        int charge;
        int x;
        int y;
        int index;
        int vx = 5;
        int vy = 5;

        public Particle(int posX, int posY, int mass,int charge1, int vx, int vy,int index) {
            this.posX = posX;
            this.posY = posY;
            this.size = 25;
            this.vx = vx;
            this.vy = vy;
            charge=charge1;
            this.index=index;
        }

        void update() {
        	
        	pentaint1[] getted= getter(depositparticles,this);
        	int [] spec=accelerationcalculator(this,getted);	
        	xacceleration=xacceleration+spec[0];
        	yacceleration=yacceleration+spec[1];
        	vx=vx+xacceleration;
        	vy=vy+yacceleration;
        	
        	this.posX += vx;
            this.posY += vy;
            x=posX;
            y=posY;

        	

            if (posX > 800 || posX < 0) {
                vx *= -1;
            }

            if (posY > 800 || posY < 0) {
                vy *= -1;
            }

            if (posX > 800) {
                posX = 800;
            }

            if (posX < 0) {
                posX = 1;
            }

            if (posY > 800) {
                posY = 800;
            }

            if (posY < 0) {
                posY = 1;
            }
            
            
            

        }

    	
    	pentaint1[] getter(List <Particle> particles,Particle cacko)
    	{
    		pentaint1 [] distances=new pentaint1[particles.size()];
    		int x=cacko.x;
    		int y=cacko.y;
    		int i=cacko.index;
    		
    		for(int j=0;j<particles.size();j++) {
    			pentaint1 inter_particle_properties=new pentaint1();
    			if(i==j) {
    				inter_particle_properties.angle=0;
    				inter_particle_properties.xdif=0;
    				inter_particle_properties.ydif=0;
    				inter_particle_properties.hypotenuse=0;
    				inter_particle_properties.charge=0;
        			distances[j]=inter_particle_properties;

    			}
    			else {
    			double angle=0;
    			int xdif=Math.abs(x-particles.get(j).x);
    			int ydif=Math.abs(y-particles.get(j).y);
    			int hypotenuse=(int) Math.sqrt(((xdif)^2)+((ydif)^2));
    			if(hypotenuse!=0)
    				angle= Math.sin(ydif/hypotenuse);
    			inter_particle_properties.angle=angle;
    			inter_particle_properties.xdif=xdif;
    			inter_particle_properties.ydif=ydif;
    			inter_particle_properties.hypotenuse=hypotenuse;
    			inter_particle_properties.charge=particles.get(j).charge;
    			distances[j]=inter_particle_properties;
    			}
    		}
    		return distances;	
    	}
    	
    	int[] accelerationcalculator(Particle jaje, pentaint1[] getted) {
    		int[] q0= new int [2];
    		double fx=0;
    		double fy=0;
    		for(int i=0;i<getted.length;i++)
    		{
    			double fc=(10.5/(getted[i].hypotenuse^2));
    			if(getted[i].charge==jaje.charge)
    				fc=fc*-1;
    			if(getted[i].angle!=0)
    			fx=fx+Math.cos(getted[i].angle)*fc;
    			if(getted[i].angle!=60)
    			fy=fy+Math.sin(getted[i].angle)*fc;
    			
    		}
		    q0[0]=(int) fx;
		    q0[1]=(int) fy;
    	    return q0;
    		
    	}
    }
}
    
