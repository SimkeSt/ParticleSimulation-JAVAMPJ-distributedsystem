import java.util.Random;

import mpi.*;

public class wqeqweq {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MPI.Init(args);
		
		int me = MPI.COMM_WORLD.Rank();
		int size = MPI.COMM_WORLD.Size();
		calculator bosko=new calculator();
		
		int[] X = new int[1000];
		int[] Y = new int[1000];
		int[] VX = new int[1000];
		int[] VY = new int[1000];
		int[] C = new int[1000];
		
		int[] X1 = new int[1000];
		int[] Y1 = new int[1000];
		int[] VX1 = new int[1000];
		int[] VY1 = new int[1000];
		int[] C1 = new int[1000];
		
		int[] X2 = new int[1000];
		int[] Y2 = new int[1000];
		int[] VX2 = new int[1000];
		int[] VY2 = new int[1000];
		int[] C2 = new int[1000];
		
		int[] X3 = new int[1000];
		int[] Y3 = new int[1000];
		int[] VX3 = new int[1000];
		int[] VY3 = new int[1000];
		int[] C3 = new int[1000];
		

		if (me == 0)
		{
			
			randomizer rajkan=new randomizer();
    		for(int i=0;i<X.length;i++) {
    			X[i]=rajkan.x();
    			Y[i]=rajkan.y();
    			VX[i]=rajkan.vel();
    			VY[i]=rajkan.vel();
    			C[i]=rajkan.c();
    		}
    		
			long k1=System.currentTimeMillis();

			for (int i=0; i<500; i++)
			{
				
				//send to 1
				MPI.COMM_WORLD.Send(X, 0, X.length, MPI.INT, 1, 0);
				MPI.COMM_WORLD.Send(Y, 0, X.length, MPI.INT, 1, 0);
				MPI.COMM_WORLD.Send(VX, 0, X.length, MPI.INT, 1, 0);
				MPI.COMM_WORLD.Send(VY, 0, X.length, MPI.INT, 1, 0);
				MPI.COMM_WORLD.Send(C, 0, X.length, MPI.INT, 1, 0);
				
				//send to 2
				MPI.COMM_WORLD.Send(X, 0, X.length, MPI.INT, 2, 0);
				MPI.COMM_WORLD.Send(Y, 0, X.length, MPI.INT, 2, 0);
				MPI.COMM_WORLD.Send(VX, 0, X.length, MPI.INT, 2, 0);
				MPI.COMM_WORLD.Send(VY, 0, X.length, MPI.INT, 2, 0);
				MPI.COMM_WORLD.Send(C, 0, X.length, MPI.INT, 2, 0);
				
				//send to 3
				MPI.COMM_WORLD.Send(X, 0, X.length, MPI.INT, 3, 0);
				MPI.COMM_WORLD.Send(Y, 0, X.length, MPI.INT, 3, 0);
				MPI.COMM_WORLD.Send(VX, 0, X.length, MPI.INT, 3, 0);
				MPI.COMM_WORLD.Send(VY, 0, X.length, MPI.INT, 3, 0);
				MPI.COMM_WORLD.Send(C, 0, X.length, MPI.INT, 3, 0);
				
				
				//receive from 1
				MPI.COMM_WORLD.Recv(X1, 0, X.length, MPI.INT, 1, 22);
				MPI.COMM_WORLD.Recv(Y1, 0, X.length, MPI.INT, 1, 22);
				MPI.COMM_WORLD.Recv(VX1, 0, X.length, MPI.INT, 1, 22);
				MPI.COMM_WORLD.Recv(VY1, 0, X.length, MPI.INT, 1, 22);
				//receieve from 2
				MPI.COMM_WORLD.Recv(X2, 0, X.length, MPI.INT, 2, 22);
				MPI.COMM_WORLD.Recv(Y2, 0, X.length, MPI.INT, 2, 22);
				MPI.COMM_WORLD.Recv(VX2, 0, X.length, MPI.INT, 2, 22);
				MPI.COMM_WORLD.Recv(VY3, 0, X.length, MPI.INT, 2, 22);	

				//receieve from 3
				MPI.COMM_WORLD.Recv(X3, 0, X.length, MPI.INT, 3, 22);
				MPI.COMM_WORLD.Recv(Y3, 0, X.length, MPI.INT, 3, 22);
				MPI.COMM_WORLD.Recv(VX3, 0, X.length, MPI.INT, 3, 22);
				MPI.COMM_WORLD.Recv(VY3, 0, X.length, MPI.INT, 3, 22);
				
				for(int q=0;q<1000;q++) {
					if(q<333) {
						X[q]=X1[q];
						Y[q]=Y1[q];
						VX[q]=VX1[q];
						VY[q]=VY1[q];
					}
					else if(q<666) {
						X[q]=X2[q];
						Y[q]=Y2[q];
						VX[q]=VX2[q];
						VY[q]=VY2[q];
					}
					else if(q<1000) {
						X[q]=X3[q];
						Y[q]=Y3[q];
						VX[q]=VX3[q];
						VY[q]=VY3[q];
					}
				}
				
				
			

			}
	    	long k2=System.currentTimeMillis()-k1;
	    	
	    	System.out.println(k2);

			
		
		}
		if(me==1)
		{
			
			int s=0;
			int e=333;
			for (int i=0; i<500; i++)
			{
				//receive
				MPI.COMM_WORLD.Recv(X, 0, X.length, MPI.INT, 0, 0);
				MPI.COMM_WORLD.Recv(Y, 0, X.length, MPI.INT, 0, 0);
				MPI.COMM_WORLD.Recv(VX, 0, X.length, MPI.INT, 0, 0);
				MPI.COMM_WORLD.Recv(VY, 0, X.length, MPI.INT, 0, 0);
				MPI.COMM_WORLD.Recv(C, 0, X.length, MPI.INT, 0, 0);
				
				
				for(int j=s;j<e;j++) {
					int[] guwop=new int[2];
					int[][] distmat=new int[X.length][5];
					distmat=bosko.aligator(X, Y, j, C);
					guwop=bosko.inkubator(VX,distmat,C,j);
					VX1[j]=+guwop[0];
					VY1[j]=+guwop[1];
					X1[j]=+VX[j];
					Y1[j]=+VY[j];
					
					 if (X1[j] > 800 || X1[j] < 0) {
						 VX1[j] *= -1;
			            }

					 if (Y1[j] > 800 || Y1[j] < 0) {
						 VY1[j] *= -1;
			            }

			            if (X1[j] > 800) {
			            	X1[j] = 800;
			            }

			            if (X1[j] < 0) {
			            	X1[j] = 1;
			            }

			            if (Y1[j] > 800) {
			            	Y1[j] = 800;
			            }

			            if (Y1[j] < 0) {
			            	Y1[j] = 1;
			            }
			            

			            
					
				}

				//sendfinishedprod
				MPI.COMM_WORLD.Send(X1, 0, X.length, MPI.INT, 0, 22);
				MPI.COMM_WORLD.Send(Y1, 0, X.length, MPI.INT, 0, 22);
				MPI.COMM_WORLD.Send(VX1, 0, X.length, MPI.INT, 0, 22);
				MPI.COMM_WORLD.Send(VY1, 0, X.length, MPI.INT, 0, 22);
				





			}

		}
		
		if(me==2)
		{
			
			int s=333;
			int e=666;
			for (int i=0; i<500; i++)
			{
				//receive
				MPI.COMM_WORLD.Recv(X, 0, X.length, MPI.INT, 0, 0);
				MPI.COMM_WORLD.Recv(Y, 0, X.length, MPI.INT, 0, 0);
				MPI.COMM_WORLD.Recv(VX, 0, X.length, MPI.INT, 0, 0);
				MPI.COMM_WORLD.Recv(VY, 0, X.length, MPI.INT, 0, 0);
				MPI.COMM_WORLD.Recv(C, 0, X.length, MPI.INT, 0, 0);

				
				for(int j=s;j<e;j++) {
					int[] guwop=new int[2];
					int[][] distmat=new int[X.length][5];
					distmat=bosko.aligator(X, Y, j, C);
					guwop=bosko.inkubator(VX,distmat,C,j);
					VX2[j]=+guwop[0];
					VY2[j]=+guwop[1];
					X2[j]=+VX[j];
					Y2[j]=+VY[j];
					
					 if (X2[j] > 800 || X2[j] < 0) {
						 VX2[j] *= -1;
			            }

					 if (Y2[j] > 800 || Y2[j] < 0) {
						 VY2[j] *= -1;
			            }

			            if (X2[j] > 800) {
			            	X2[j] = 800;
			            }

			            if (X2[j] < 0) {
			            	X2[j] = 1;
			            }

			            if (Y2[j] > 800) {
			            	Y2[j] = 800;
			            }

			            if (Y2[j] < 0) {
			            	Y2[j] = 1;
			            }
			            
					
				}
				
				//sendfinishedprod
				MPI.COMM_WORLD.Send(X2, 0, X.length, MPI.INT, 0, 22);
				MPI.COMM_WORLD.Send(Y2, 0, X.length, MPI.INT, 0, 22);
				MPI.COMM_WORLD.Send(VX2, 0, X.length, MPI.INT, 0, 22);
				MPI.COMM_WORLD.Send(VY2, 0, X.length, MPI.INT, 0, 22);


			}

		}
		
		if(me==3)
		{
			
			int s=666;
			int e=1000;
			for (int i=0; i<500; i++)
			{
				//receive
				MPI.COMM_WORLD.Recv(X, 0, X.length, MPI.INT, 0, 0);
				MPI.COMM_WORLD.Recv(Y, 0, X.length, MPI.INT, 0, 0);
				MPI.COMM_WORLD.Recv(VX, 0, X.length, MPI.INT, 0, 0);
				MPI.COMM_WORLD.Recv(VY, 0, X.length, MPI.INT, 0, 0);
				MPI.COMM_WORLD.Recv(C, 0, X.length, MPI.INT, 0, 0);
				
				for(int j=s;j<e;j++) {
					int[] guwop=new int[2];
					int[][] distmat=new int[X.length][5];
					distmat=bosko.aligator(X, Y, j, C);
					guwop=bosko.inkubator(VX,distmat,C,j);
					VX3[j]=+guwop[0];
					VY3[j]=+guwop[1];
					X3[j]=+VX[j];
					Y3[j]=+VY[j];
					
					 if (X3[j] > 800 || X3[j] < 0) {
						 VX3[j] *= -1;
			            }

					 if (Y3[j] > 800 || Y3[j] < 0) {
						 VY3[j] *= -1;
			            }

			            if (X3[j] > 800) {
			            	X3[j] = 800;
			            }

			            if (X3[j] < 0) {
			            	X3[j] = 1;
			            }

			            if (Y3[j] > 800) {
			            	Y3[j] = 800;
			            }

			            if (Y3[j] < 0) {
			            	Y3[j] = 1;
			            }
			            
					
				}

				//sendfinishedprod
				MPI.COMM_WORLD.Send(X3, 0, X.length, MPI.INT, 0, 22);
				MPI.COMM_WORLD.Send(Y3, 0, X.length, MPI.INT, 0, 22);
				MPI.COMM_WORLD.Send(VX3, 0, X.length, MPI.INT, 0, 22);
				MPI.COMM_WORLD.Send(VY3, 0, X.length, MPI.INT, 0, 22);



			}

		}
		
		
		MPI.Finalize();
	}

}


class randomizer {
	int c() {
    	Random rand= new Random();
    	int rand1=rand.nextInt(2);
    	if(rand1==0)
    		rand1=-1;
    	return rand1;
    	}

    
    int vel() {
    	Random rand= new Random();
    	int rand1= rand.nextInt(10);
    	if(rand1>5)
    		rand1=(rand1-5)*(-1);
    	return rand1;
    } 
    
    int x() {
    	Random rand= new Random();
    	int rand1= rand.nextInt(800);
    	return rand1;
    }
    
    int y() {
    	Random rand= new Random();
    	int rand1= rand.nextInt(600);
    	return rand1;
    }
}

class calculator {
	
	public int[][] aligator(int[] X, int [] Y, int index,int[] C) {
		int [][] distmat1=new int[X.length][5];
		for(int i=0;i<X.length;i++) {
			if(i==index) {
				distmat1[i][0]=0;
				distmat1[i][1]=0;
				distmat1[i][2]=C[i];
				distmat1[i][3]=0;
				distmat1[i][4]=0;
			}
			else {
				distmat1[i][0]=Math.abs(X[index]-X[i]);
				distmat1[i][1]=Math.abs(Y[index]-Y[i]);
				distmat1[i][2]=C[i];
				int angle = 0;
				int hypotenuse=(int) Math.sqrt(((distmat1[i][0])^2)+((distmat1[i][1])^2));
    			if(hypotenuse!=0)
    				angle= (int) Math.sin(distmat1[i][1]/hypotenuse);
    			distmat1[i][3]=angle;
				distmat1[i][4]=hypotenuse;
				
			}
				
		}
		return distmat1;
		
	}
	
	public int[] inkubator(int [] V, int [][] distmat,int [] C,int index){
		
		int fx=0;
		int fy=0;
		int q[]=new int[2];
		for(int i=0;i<V.length;i++)
		{
			double fc=(10.5/(distmat[i][4]^2));
			if(C[index]==distmat[i][2])
				fc=fc*-1;
			if(distmat[i][3]!=0)
			fx=(int) (fx+Math.cos(distmat[i][3])*fc);
			if(distmat[i][3]!=60)
			fy=(int) (fy+Math.sin(distmat[i][3])*fc);
			
		}
		q[0]=fx;
		q[1]=fy;
		return q;
		
	}
	
}